/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author BRANDON DEVOS 
 */
public class Clientes {
    private int id;
    private String nombre;
    private String apellido;
    private String usuario;
    private String direccion;
    private String email;
    private String clave;
    private String telefono;
    private Conector conector = new Conector();
    
    public Clientes(){}
    public Clientes(int id, String nombre, String apellido, String usuario, String direccion, String email, String clave,String telefono) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.usuario = usuario;
        this.direccion = direccion;
        this.email = email;
        this.clave = clave;
        this.telefono = telefono;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public Conector getConector() {
        return conector;
    }

    public void setConector(Conector conector) {
        this.conector = conector;
    
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    
    public boolean guardarClientes(){
       String sql = "INSERT INTO clientes(nombre,apellido,usuario,direccion,email,clave,telefono) VALUES (?,?,?,?,?,?,?)";
        try{
           conector.conectar();
           int resultado = conector.executeUpdate(sql,nombre,apellido,usuario, direccion,email,clave,telefono);
           return resultado > 0;
       } catch(SQLException e){
            System.out.println("se ha producido unerror al guardar cliente" + e.getMessage());
            return false;
       }
       }
    public boolean actualizarClientes(){
        String sql = "UPDATE clientes SET nombre =?, apellido=?, usuario=?, direccion=?, email=?, clave=?,telefono=? WHERE id=?";
        try{
            conector.conectar();
         int resultado = conector.executeUpdate(sql, nombre, apellido,usuario,direccion,email,clave,telefono, id);
         return resultado > 0;
       }catch(SQLException e){
            System.out.println(" hubo un error al actualizar a cliente por favor vuelva a intentarlo nuevamente:" + e.getMessage());
            return false;
        }
    }
        public boolean eliminarCliente(){
        String sql = "DELETE FROM clientes WHERE id=?";
        try{
            conector.conectar();
            int resultado = conector.executeUpdate(sql, id);
            return resultado > 0;
        }catch(SQLException e){
            System.out.println("hubo un error al eliminar al cliente revise los campos o vuelva a intentarlo" + e.getMessage());
            return false;
        }
        }
    
        
        public List<Clientes> listarClientes(){
            List<Clientes> listar = new ArrayList<>();
            String sql = "SELECT * FROM clientes";
            try{
                conector.conectar();
                ResultSet rs = conector.executeSelect(sql);
                while (rs.next()){
                 Clientes c = new Clientes(
                 rs.getInt("id"),
                 rs.getString("nombre"),
                 rs.getString("apellido"),
                 rs.getString("usuario"),
                 rs.getString("direccion"),
                 rs.getString("email"),
                 rs.getString("clave"),
                 rs.getString("telefono")
                );
                 listar.add(c);
                }
            }catch (SQLException e){
                System.out.println(" se a producido un error al listar al cliente vuelva a intentarlo:" + e.getMessage());
            }
            return listar;
        }
    }
