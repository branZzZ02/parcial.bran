/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Main;

import Clases.Conector;
import Formularios.FrmLogin;
import java.sql.*;

/**
 *
 * @author Ing. Narvaez Mejia
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        FrmLogin L = new FrmLogin();
        L.setVisible(true);
    }
    
}
